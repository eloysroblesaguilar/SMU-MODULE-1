package com.company;

public class DebuggingPractice {

    public static void main(String[] args) {
        int a = 1;
        int b = 45;
        int c = 352;
        int sum = 0;
        String message = "This is a test message!";
        String message2 = "This is a second message!!!";

        System.out.println("Value of a is: " + a);
        System.out.println("Value of b is " + b);
        System.out.println("Value of c is: " + c);

        sum = a + b + c;

        System.out.println("Sum = " + sum);
    }

}
